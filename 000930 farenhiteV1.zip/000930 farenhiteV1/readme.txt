All HAL exept i2c
no rtc
no sleep mode
stable
-- last modify: 000901

RTC -> LL
No sleep mode
Stable
-- last modify: 000912

Flag array name -> _mainFlag
uart.c -> "ZM_STM_com_uart.c"
generate .c .h external
STOP_mode_Enable -> enter_in_stop_mode
358 lcd_driver.c comment
lcd_led setting
add a new flag EIS   //_F7  > external interrupt source
lcd led remain 1s after any input (key or zwave)
learn is fixed (cpu won go to sleep after learn command and wait for respond)
timers are erased
all variables are volatile now

-- last modify: 000916

led_lcd just will be on after a ext interrupt occur


