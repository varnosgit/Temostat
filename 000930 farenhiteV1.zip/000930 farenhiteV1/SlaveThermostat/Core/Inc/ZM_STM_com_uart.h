#ifndef _UART_H
#define _UART_H

#include "stm32l0xx_hal.h"

void put_str(char *str);
void send_data(int temp);
void get_data(void);
int hex2dec(char *str);

void BAT_L_F(int bat);
void ANT_L_F(int ant);
void digit_disp(int n,char c);

#endif
