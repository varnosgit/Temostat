/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l0xx_hal.h"
#include "stm32l0xx.h"
#include "stm32l0xx_ll_i2c.h"
#include "stm32l0xx_ll_crs.h"
#include "stm32l0xx_ll_rcc.h"
#include "stm32l0xx_ll_bus.h"
#include "stm32l0xx_ll_system.h"
#include "stm32l0xx_ll_exti.h"
#include "stm32l0xx_ll_cortex.h"
#include "stm32l0xx_ll_utils.h"
#include "stm32l0xx_ll_pwr.h"
#include "stm32l0xx_ll_dma.h"
#include "stm32l0xx_hal.h"
#include "stm32l0xx_ll_gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ZM_STM_com_uart.h"
#include "LM75_n.h"
#include "LCD_Driver.h"

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
#define ledTimer 178000
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Dec_BT_Pin LL_GPIO_PIN_14
#define Dec_BT_GPIO_Port GPIOC
#define Dec_BT_EXTI_IRQn EXTI4_15_IRQn
#define Inc_BT_Pin LL_GPIO_PIN_15
#define Inc_BT_GPIO_Port GPIOC
#define Inc_BT_EXTI_IRQn EXTI4_15_IRQn
#define ST_WKUP_Pin LL_GPIO_PIN_0
#define ST_WKUP_GPIO_Port GPIOA
#define ST_WKUP_EXTI_IRQn EXTI0_1_IRQn
#define ZW_CS_Pin LL_GPIO_PIN_1
#define ZW_CS_GPIO_Port GPIOA
#define cfInput_Pin LL_GPIO_PIN_4
#define cfInput_GPIO_Port GPIOA
#define cfInput_EXTI_IRQn EXTI4_15_IRQn
#define LCD_CS_Pin LL_GPIO_PIN_5
#define LCD_CS_GPIO_Port GPIOA
#define LCD_WR_Pin LL_GPIO_PIN_6
#define LCD_WR_GPIO_Port GPIOA
#define LCD_DATA_Pin LL_GPIO_PIN_7
#define LCD_DATA_GPIO_Port GPIOA
#define LCD_LED_Pin LL_GPIO_PIN_1
#define LCD_LED_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

///***************(Type Definition)***********************

typedef enum
{		
	IMS,													//_F0   > IDEL Mode Status (0: Disable , 1: Enable)
	WITM,											//_F1   > WAKEUP Interrupt Mode (0: Disable ,  UART Interrupt , RTC Interrupt )
	UBS,												//_F2   > UART Busy Status (0: Disable , 1: Enable)	
	LS,														//_F3   > Loading State (0: Disable , Initialize  ,  Loading in Display)
	ZWC,												//_F4   > Zwave Module Connection Status ( Disconnect ,  Connecting ,  Connected)
	RTCC,											//_F5   > RTC Inttrupt Counter (Is used for Reading Temperture Sensor)	
	TMC,												//_F6   > Number of Counting for Reading Temperture Sensor		
	EIS                           //_F7  > external interrupt source
}Flags;
		
typedef enum
{	
	Disable,										//_S0   > DISABLE Status
	Enable,											//_S1   > ENABLE Status
	UIT,													//_S2   > UART Interrupt 
	RIT,													//_S3   > RTC Interrupt
	BIT,													//_S4   > Button Pressed Interrupt
	IZM,													//_S5   > Initialize Mode
	DLM,												//_S6   > Display Loading Mode
	ZDC,													//_S7   > Zwave Module Disconnected
	ZCO,												//_S8   > Zwave Module Connecting
	ZCD 													//_S9   > Zwave Module Connected		
}Status;


#define ON 						1				
#define OFF					0				


/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
