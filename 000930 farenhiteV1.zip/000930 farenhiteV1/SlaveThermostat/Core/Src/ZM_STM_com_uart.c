/* USER CODE BEGIN Includes */

#include "main.h"
//#include "Command_Control.h"

/* External variables --------------------------------------------------------*/


extern UART_HandleTypeDef huart2;
volatile extern char Rx_data[2];

extern char strr[20];
extern char strd[40];
volatile extern int BAT_L,ANT_L,SP;
volatile extern int _mainFlag[15];

void put_str(char *str)
{
	while(*str!=0)
  {		
		HAL_UART_Transmit(&huart2,(unsigned char*)str,1,1);
//		LL_mDelay(2);
    str++;
  }	
}


void send_data(int temp)
{
	memset(strd,0,sizeof(strd));
	sprintf(strd,"%d\r\n",temp);
	LL_GPIO_ResetOutputPin(ZW_CS_GPIO_Port,ZW_CS_Pin);
	LL_mDelay(100);
	put_str(strd);
	LL_mDelay(200);
	LL_GPIO_SetOutputPin(ZW_CS_GPIO_Port,ZW_CS_Pin);
}



//* Recieved data from Modules

void get_data(void)
{
	char data[16];
	char * pch;
	char sr1[3],sr2[3];
	int n1,n2;
	int ANT_V,BAT_V;
	
	memset(data,0,16);

//	lcd_clear();
//	lcd_puts(strr);

	///Searching for SetPoint String
	
	  if (strstr(strr,"SetPoint") != NULL)
				{
					sprintf(data, "%s", strstr(strr,"SetPoint"));
					pch = strchr(data,':');

						sr1[0]='\0';
						strncat (sr1, pch+1, 1);			// HL digit
						sr1[1] = '\0';

						sr2[0]='\0';
						strncat (sr2, pch+2, 1);			// LL digit
						sr2[1] = '\0';

					n1= hex2dec(sr1);			///High Digit
					n2= hex2dec(sr2);			///Low Degit
					SP=n1*16+n2;
					

				if( _mainFlag[LS]==DLM)	 									// If Steady to Display Parameters
					{				
						LCD_Digit(SP,'S');
						_mainFlag[IMS]=Enable;				// Idel Mode is Enable	
					}
				}
		
		
	
///Searching for BATTERY LEVEL String	
	  if (strstr(strr,"BAT_L") != NULL)
				{
					sprintf(data, "%s", strstr(strr,"BAT_L"));
							
					pch = strchr(data,':');

						sr1[0]='\0';
						strncat (sr1, pch+1, 1);			// HL digit
						sr1[1] = '\0';

						sr2[0]='\0';
						strncat (sr2, pch+2, 1);			// LL digit
						sr2[1] = '\0';

						n1= hex2dec(sr1);			///High Digit
						n2= hex2dec(sr2);			///Low Degit
						BAT_V=n1*16+n2;


					BAT_L_F(BAT_V);
					
						_mainFlag[IMS]=Enable;				// Idel Mode is Enable	

				}
		
		
		
		///Searching for BATTERY LEVEL String
	if (strstr(strr,"ANT_L") != NULL)
				{
					sprintf(data, "%s", strstr(strr,"ANT_L"));
							
					pch = strchr(data,':');

						sr1[0]='\0';
						strncat (sr1, pch+1, 1);			// HL digit
						sr1[1] = '\0';

						sr2[0]='\0';
						strncat (sr2, pch+2, 1);			// LL digit
						sr2[1] = '\0';

						n1= hex2dec(sr1);			///High Digit
						n2= hex2dec(sr2);			///Low Degit
						ANT_V=n1*16+n2;
										
						ANT_L_F(ANT_V);
					
						_mainFlag[IMS]=Enable;				// Idel Mode is Enable	
		
					
					}
		
	///Searching for LEARNING START String
	  if ( strstr(strr,"LEARN") != NULL)
				{
					LCD_Sign('L',1);							 // Zwave Module is Connecting
		//			_mainFlag[IMS]=Enable;				// Idel Mode is Enable			
				}

	///Searching for INCLUDED status	
    if (strstr(strr,"INCLUDED") != NULL)
					{
							_mainFlag[ZWC]=ZCD;						
							LCD_Sign('L',0);				 // Zwave Module is Connected
							_mainFlag[IMS]=Enable;				// Idel Mode is Enable
					}

    ///Searching for EXCLUDED status
   	if (strstr(strr,"NOTINCLUD") != NULL)
				{
					_mainFlag[ZWC]=ZDC;
						LCD_Sign('L',0);				// Zwave Module is Disconnected
					_mainFlag[IMS]=Enable;				// Idel Mode is Enable
				}

	///Searching for LEARNING TIMEOUT status
    
	if ((strstr(strr,"LTIMEOUT") != NULL)||(strstr(strr,"LFAILED") != NULL))
				{
						if( _mainFlag[ZWC]==ZCD)   // Zwave Module is Connected
								LCD_Sign('L',0);
						else												// Zwave Module is Disconnected
							LCD_Sign('L',0);
						
							_mainFlag[IMS]=Enable;				// Idel Mode is Enable
				}
				
	
	memset(strr,0,20);

		
}

int hex2dec(char *str)
{
	int n;
	if (strchr(str,'A'))
						n=10;
					else if (strchr(str,'B'))
						n=11;
					else if (strchr(str,'C'))
						n=12;
					else if (strchr(str,'D'))
						n=13;
					else if (strchr(str,'E'))
						n=14;
					else if (strchr(str,'F'))
						n=15;
					else
						n=atoi(str);
					
					return n;
}


void BAT_L_F(int bat)
{
	if(bat<20)
			BAT_L=1;
	if((bat>20)&&(bat<50))
			BAT_L=2;
	if((bat>=50)&&(bat<80))
			BAT_L=3;
	if((bat>=80)&&(bat<100))
			BAT_L=4;
	if(bat>=100)
			BAT_L=5;
	
				LCD_Sign('X',BAT_L);	
}



void ANT_L_F(int ant)
{	
	if(ant<30)
			ANT_L=0;
	if((ant>=30)&&(ant<=50))
			ANT_L=1;
	if((ant>50)&&(ant<=70))
		ANT_L=2;
	if((ant>70)&&(ant<=90))
		ANT_L=3;
	if((ant>90)&&(ant<=100))
		ANT_L=4;
	if(ant>100)
		ANT_L=5;

	
	
//	if( Flag[LS]==DLM)	 									// If Steady to Display Parameters
//			{
//				Flag[NCD]++;										// Increase Counter Of Change in Display
//		//		Anttena_Level(ANT_L);
//		//		Battery_Level(BAT_L);
//				EPD_2IN66_Display(BlackImage);
//			}



}





