
#include "HT1621.h"
#include "awu.h"

#include "stm32f0xx_hal.h"

#include <string.h>

extern HT1621_Map Seg_LCD; //Caution! No variable definitions after first instruction.

void HT1621_SendBits(uint8_t sdata,uint8_t cnt) //Send cnt MSB bits of sdata.
{ 
  uint8_t i; 
  for(i=0;i<cnt;i++) 
    { 

      WR0;
      if(sdata&0x80){
	DATA1;
      }else{
	DATA0;
      }
      WR1;
      sdata<<=1; 
    } 
}

void HT1621_SendCmd(uint8_t command) //Write to the command registers.
{ 
  CS0;                     //Select,
  HT1621_SendBits(0x80,4); //Next byte is a command, (implemented as 1000+8
                           // bits, rather than the 100+9 bits specified
                           // in the datasheet.)
  HT1621_SendBits(command,8);//Write the 8 bit command value,
  CS1;                     //Deselect
}

void HT1621_Write(uint8_t addr,uint8_t sdata) //Write sdata to address addr:
{ 
  addr<<=2; 
  CS0; 
  HT1621_SendBits(0xa0,3);     //Write following to data memory
  HT1621_SendBits(addr,6);     // at address addr
  HT1621_SendBits(sdata,8);    // this is the data to be written.
  CS1; 
} 

void HT1621_AllOff(uint8_t number) //Clear all segments.
{
  uint8_t i; 
  uint8_t addr=0; 
  for(i=0;i<number;i++) 
    { 
      HT1621_Write(addr,0x00); 
      addr+=2; 
    } 
}

void HT1621_AllOn(uint8_t number) //Set all segments.
{
  uint8_t i; 
  uint8_t addr=0; 
  for(i=0;i<number;i++) 
    {
      HT1621_Write(addr,0xff);
HAL_Delay(500);			
      addr+=2; 
    } 
}

void HT1621_Init(void)//Initialize the HT1621 chip.
{
  CS1;
  DATA1;
  WR1;
//  AWU_Init(AWU_TIMEBASE_512MS);
//  halt();
  //  Delay(500);   //TODO: This can be shorter.
  HT1621_SendCmd(Sys_en);
  HT1621_SendCmd(RCosc);    
  HT1621_SendCmd(ComMode);  
  HT1621_SendCmd(LCD_on);
	
	Seg_LCD.digit[0][0]=0x0F;
	Seg_LCD.digit[0][1]=0x0A;
	
	Seg_LCD.digit[1][0]=0x00;
	Seg_LCD.digit[1][1]=0x0A;  
	
	Seg_LCD.digit[2][0]=0x0B;
	Seg_LCD.digit[2][1]=0x0C;
	
	Seg_LCD.digit[3][0]=0x09;
	Seg_LCD.digit[3][1]=0x0E;  
	
	
	Seg_LCD.digit[4][0]=0x04;
	Seg_LCD.digit[4][1]=0x0E;
	
	Seg_LCD.digit[5][0]=0x0D;
	Seg_LCD.digit[5][1]=0x06;  
	
	Seg_LCD.digit[6][0]=0x0F;
	Seg_LCD.digit[6][1]=0x06;
	
	Seg_LCD.digit[7][0]=0x08;
	Seg_LCD.digit[7][1]=0x0A;  
	
	Seg_LCD.digit[8][0]=0x0F;
	Seg_LCD.digit[8][1]=0x0E;
	
	Seg_LCD.digit[9][0]=0x0D;
	Seg_LCD.digit[9][1]=0x0E;  
	
	  
	
	
}    

void HT1621_Refresh(HT1621_Map * LCD_data) 				//Display the prepared number.  
{
	int d=0;
//	HT1621_ValuesConstructor(Seg_LCD);
	
  uint8_t i=0;
	


  //Show the number itself:
 
      HT1621_Write(0,LCD_data->digit[d][0]);
			HT1621_Write(1,LCD_data->digit[d][1]);
}

void  HT1621_ValuesConstructor(HT1621_Map * LCD_data)
	{
/*0,1,2,3,4,5,6,7,8,9,A,b,C,c,d,E,F,H,h,L,n,N,o,P,r,t,U,-, ,*/
//{0x7D,0x60,0x3E,0x7A,0x63,0x5B,0x5F,0x70,0x7F,0x7B,0x77,0x4F,0x1D,0x0E,0x6E,0x1F,0x17,0x67,0x47,0x0D,0x46,0x75,0x37,0x06,0x0F,0x6D,0x02,0x00,};
//AO!: The figures and numbers do not match! 29 figures, 28 numbers.
  

  
		
}


void HT1621_Convert(long number, HT1621_Map * LCD_data)
  {
  int CurrentDigit;
  int i;

  //Set divisor array: 
  const long divisors[]={1, 10, 100, 1000, 10000, 100000};
  const long MaxRepresentable = 99999;

    //Check that the number is smaller than MaxRepresentable
    if(number > MaxRepresentable){
      //printf("Number too big.\n");
      //Set all digits to '-'
      for(CurrentDigit=5;CurrentDigit>=0;--CurrentDigit){
//	LCD_data->digit[CurrentDigit]=LCD_data->map[26]; //display '-'
//      }
//      return;
//    }
//    if (number <0){  //Check the sign of the number.
//      number= -number;
//      LCD_data->digit[5]=LCD_data->map[26]; //display '-'
//    }else{
//      LCD_data->digit[5]=LCD_data->map[27]; //display ' '
//    }
//    //Start from the highest digit, keep subtracting to obtain the value of
//    // that digit. Move on to the next smaller digit.
//    for(CurrentDigit = 4; CurrentDigit>=0; --CurrentDigit){
//      LCD_data->digit[CurrentDigit]=0;
//      i=0;
//      while(number >= divisors[CurrentDigit]){
//	  number=number-divisors[CurrentDigit];
//	  ++i;
      }
//      LCD_data->digit[CurrentDigit]=LCD_data->map[i];
    }
}


//Do not show the leading '0' in the number.
//If the number is negative, adjust it so that the negative sign
// appears to the left of the leftmost displayed digit.
//If there is a decimal point displayed, adjust blanking such that
// there is at least one zero to the left of decimal point
// and no blanking to the right of the decimal point.
void HT1621_Blanking (HT1621_Map * LCD_data){
  uint8_t i;
  uint8_t s;
  uint8_t decimalPtSave;
//  s= LCD_data->digit[5]; //Check the first digit. Copy it into variable s.

  decimalPtSave=0; //if decimal point was set to location 4, 
                   // it is an unusual case. Treated below:
//  if (LCD_data->decimalPt==4){
//    decimalPtSave=LCD_data->decimalPt;
//    LCD_data->decimalPt=10;
//  }

  for (i=4; i>0;--i){  //For i= digits '4' to '1'
    //If there is a decimal point here, do not blank further:
//    if (LCD_data->decimalPt==i){
//      LCD_data->digit[5]=LCD_data->map[27]; //Clear leftmost digit.
//      LCD_data->digit[i+1]=s;//ifnonzero, copy s into the higher order digit.
//      return;
//    }//End: decimal point adjustment.
//    if (LCD_data->digit[i]==LCD_data->map[0]){ //If digit itself is zero
//	LCD_data->digit[i]=LCD_data->map[27];    //make it a blank.
//    }else{
//      LCD_data->digit[5]=LCD_data->map[27]; //Clear leftmost digit.
//      LCD_data->digit[i+1]=s;//ifnonzero, copy s into the higher order digit.
//      return;                //Return.
//    }
  }
  //If we came all the way to here, we have reached the rightmost digit.
  //Bring the sign next to it:
//  LCD_data->digit[5]=LCD_data->map[27]; //Clear leftmost digit.
//  LCD_data->digit[1]=s;//ifnonzero, copy s into the higher order digit.
//  if (decimalPtSave){
//    LCD_data->decimalPt=4;
//  }
}

void HT1621_PortInit(void){
  //Set GPIO for HT1621:
//  GPIO_Init(HT1621Port, HT1621WR, GPIO_MODE_OUT_PP_LOW_FAST);
//  GPIO_Init(HT1621Port, HT1621Data, GPIO_MODE_OUT_PP_LOW_FAST);
//  GPIO_Init(HT1621Port, HT1621CS, GPIO_MODE_OUT_PP_LOW_FAST);

}


