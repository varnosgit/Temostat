/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32l0xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32l0xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern uint8_t cfStat;
extern RTC_HandleTypeDef hrtc;
extern UART_HandleTypeDef huart2;
/* USER CODE BEGIN EV */

extern char strd[40],Rx_data[2],Rx_Buffer[20];
extern char strr[20];
volatile extern int Rx_index,BAT_L,ANT_L,SP;
volatile extern int _mainFlag[15];

extern int MIN_SetPoint,MAX_SetPoint;

volatile extern int keyRemains;
volatile extern uint32_t lcdLED_counter;


extern void SystemClock_Config(void);

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M0+ Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVC_IRQn 0 */

  /* USER CODE END SVC_IRQn 0 */
  /* USER CODE BEGIN SVC_IRQn 1 */

  /* USER CODE END SVC_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32L0xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32l0xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles RTC global interrupt through EXTI lines 17, 19 and 20 and LSE CSS interrupt through EXTI line 19.
  */
void RTC_IRQHandler(void)
{
  /* USER CODE BEGIN RTC_IRQn 0 */

  /* USER CODE END RTC_IRQn 0 */
  HAL_RTCEx_WakeUpTimerIRQHandler(&hrtc);
  /* USER CODE BEGIN RTC_IRQn 1 */

  /* USER CODE END RTC_IRQn 1 */
}

/**
  * @brief This function handles EXTI line 0 and line 1 interrupts.
  */
void EXTI0_1_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI0_1_IRQn 0 */
					HAL_ResumeTick();
				SystemClock_Config();
				HAL_PWR_DisableSleepOnExit();
				_mainFlag[EIS] = Enable;
					lcdLED_counter =0;
				_mainFlag[IMS]=Disable;
  /* USER CODE END EXTI0_1_IRQn 0 */
  if (LL_EXTI_IsActiveFlag_0_31(LL_EXTI_LINE_0) != RESET)
  {
    LL_EXTI_ClearFlag_0_31(LL_EXTI_LINE_0);
    /* USER CODE BEGIN LL_EXTI_LINE_0 */

    /* USER CODE END LL_EXTI_LINE_0 */
  }
  /* USER CODE BEGIN EXTI0_1_IRQn 1 */

  /* USER CODE END EXTI0_1_IRQn 1 */
}

/**
  * @brief This function handles EXTI line 4 to 15 interrupts.
  */
void EXTI4_15_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI4_15_IRQn 0 */
				HAL_ResumeTick();
				SystemClock_Config();
				HAL_PWR_DisableSleepOnExit();
				_mainFlag[EIS] = Enable;
					lcdLED_counter =0;
					LCD_LED(1);
				_mainFlag[IMS]=Disable;
				_mainFlag[WITM]=BIT;

  /* USER CODE END EXTI4_15_IRQn 0 */
  if (LL_EXTI_IsActiveFlag_0_31(LL_EXTI_LINE_4) != RESET)
  {
					cfStat = 1 - cfStat;
					LCD_Sign('C',cfStat + 1);
				LCD_Sign('T',cfStat + 1);
		
		 	LCD_Digit(LM75_Temperature(),'C');
		LCD_Digit(SP,'S');
					LL_mDelay(350);
    LL_EXTI_ClearFlag_0_31(LL_EXTI_LINE_4);
    /* USER CODE BEGIN LL_EXTI_LINE_4 */
//			cfStat = 1 - cfStat;
//					LCD_Sign('C',cfStat + 1);
//					LL_mDelay(350);
    /* USER CODE END LL_EXTI_LINE_4 */
  }
  if (LL_EXTI_IsActiveFlag_0_31(LL_EXTI_LINE_14) != RESET)
  {
    LL_EXTI_ClearFlag_0_31(LL_EXTI_LINE_14);
    /* USER CODE BEGIN LL_EXTI_LINE_14 */
		
		
			//If the decrease button is pushed			
		if(LL_GPIO_IsInputPinSet(Dec_BT_GPIO_Port , Dec_BT_Pin)==0)
		{
		SP--;
			keyRemains++;
		if(SP<MIN_SetPoint)
			{
				SP=MIN_SetPoint;
			}
		
			_mainFlag[WITM]=BIT;
		}
		
		
		
    /* USER CODE END LL_EXTI_LINE_14 */
  }
  if (LL_EXTI_IsActiveFlag_0_31(LL_EXTI_LINE_15) != RESET)
  {
    LL_EXTI_ClearFlag_0_31(LL_EXTI_LINE_15);
    /* USER CODE BEGIN LL_EXTI_LINE_15 */

			if(LL_GPIO_IsInputPinSet(Inc_BT_GPIO_Port , Inc_BT_Pin)==0)
		{
		SP++;
			keyRemains++;
		if(SP>MAX_SetPoint)
			{
				SP=MAX_SetPoint;
			}
		
			_mainFlag[WITM]=BIT;
		}
		
			
    /* USER CODE END LL_EXTI_LINE_15 */
  }
  /* USER CODE BEGIN EXTI4_15_IRQn 1 */

  /* USER CODE END EXTI4_15_IRQn 1 */
}

/**
  * @brief This function handles USART2 global interrupt / USART2 wake-up interrupt through EXTI line 26.
  */
void USART2_IRQHandler(void)
{
  /* USER CODE BEGIN USART2_IRQn 0 */

  /* USER CODE END USART2_IRQn 0 */
  HAL_UART_IRQHandler(&huart2);
  /* USER CODE BEGIN USART2_IRQn 1 */
  	
  /* USER CODE END USART2_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/*
*
*/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{

	if (huart->Instance ==USART2 )  //current UART USART2
	{
		
				HAL_UART_Receive_IT(&huart2,(unsigned char*)Rx_data,1);
		if(Rx_index==0)
		{
					fflush (stdout) ;
					Rx_Buffer[0]='\0';					//clear buffer
					memset(Rx_Buffer,0,20);
		}
		
		if(Rx_data[0]!=13)				//if recived data diffrent from asci code 13 (Enter)
					{
						Rx_Buffer[Rx_index++]=Rx_data[0];
					}
		else											//if recived Enter
					{
						Rx_index=0;
						strcpy(strr,Rx_Buffer);
						get_data();
//						LCD_LED(0);
					}	
					

	}
}


/*
*
*/
void HAL_RTCEx_WakeUpTimerEventCallback(RTC_HandleTypeDef *hrtc)
{
		if(_mainFlag[IMS]==Enable)
		{														
				HAL_ResumeTick();
				SystemClock_Config();
				HAL_PWR_DisableSleepOnExit();
				_mainFlag[IMS]=Disable;
		}
		_mainFlag[WITM]=RIT;
}



/* USER CODE END 1 */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
